# Info

> - przy zmianie Index na index nie dziala !!
